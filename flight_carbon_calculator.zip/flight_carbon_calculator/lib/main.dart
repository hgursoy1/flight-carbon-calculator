import 'package:flight_carbon_calculator/ui/flight_carbon_footprint_calculator_home_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(FlightCarbonFootprintCalculatorApp());
}

class FlightCarbonFootprintCalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FlightCarbonFootprintCalculatorHomePage(),
    );
  }
}
