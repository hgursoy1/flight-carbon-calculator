import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart' show required;

class CarbonFootprint extends Equatable {
  const CarbonFootprint({
    @required this.carbonFootprintValue,
    @required this.url,
  })  : assert(carbonFootprintValue != null),
        assert(url != null);

  final num carbonFootprintValue;
  final String url;

  factory CarbonFootprint.fromJson(Map<String, dynamic> json) {
    return CarbonFootprint(
      carbonFootprintValue: json['footprint'],
      url: json['details_url'],
    );
  }

  @override
  List<Object> get props => [
        carbonFootprintValue,
        url,
      ];
}
