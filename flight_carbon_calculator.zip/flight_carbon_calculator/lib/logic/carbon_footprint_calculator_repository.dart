import 'dart:convert';

import 'package:flight_carbon_calculator/model/carbon_footprint.dart';
import 'package:http/http.dart' as http;
import 'package:meta/meta.dart' show required;

class CarbonFootprintCalculatorRepository {
  Future<CarbonFootprint> calculateCarbonFootprintBetweenTwoDestinations({
    @required String departureAirportCode,
    @required String arrivalAirportCode,
  }) async {
    final response = await http.get(
      Uri.https('api.goclimate.com', '/v1/flight_footprint', {
        'segments[0][origin]': departureAirportCode,
        'segments[0][destination]': arrivalAirportCode,
        'cabin_class': 'economy',
        'currencies[]': 'EUR'
      }),
      headers: {
        'Authorization':
            'Basic ' + base64Encode(utf8.encode('470721529a39a3d47858d7c5')),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    );

    try {
      return CarbonFootprint.fromJson(json.decode(response.body));
    } catch (_) {
      return null;
    }
  }
}
