import 'package:bloc/bloc.dart';
import 'package:flight_carbon_calculator/logic/carbon_footprint_calculator_repository.dart';
import 'package:flight_carbon_calculator/logic/carbon_footprint_calculator_state.dart';
import 'package:meta/meta.dart' show required;

class CarbonFootprintCalculatorCubit
    extends Cubit<CarbonFootprintCalculatorState> {
  CarbonFootprintCalculatorCubit()
      : super(
          CarbonFootprintCalculatorInitialState(),
        );

  final _repository = CarbonFootprintCalculatorRepository();

  Future<void> getCarbonPrintInformationForTwoDestinations({
    @required String departureAirportCode,
    @required String arrivalAirportCode,
  }) async {
    emit(CarbonFootprintCalculatorLoadingState());
    final response =
        await _repository.calculateCarbonFootprintBetweenTwoDestinations(
      departureAirportCode: departureAirportCode,
      arrivalAirportCode: arrivalAirportCode,
    );

    if (response == null) {
      emit(CarbonFootprintCalculatorErrorState(
          'There was something wrong during the calculation.\nPlease be sure that you are entering correct values.'));
    } else {
      emit(CarbonFootprintCalculatorSuccessState(response));
    }
  }
}
