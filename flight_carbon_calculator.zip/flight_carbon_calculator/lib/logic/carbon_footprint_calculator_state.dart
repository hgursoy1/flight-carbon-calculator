import 'package:equatable/equatable.dart';
import 'package:flight_carbon_calculator/model/carbon_footprint.dart';

class CarbonFootprintCalculatorState extends Equatable {
  const CarbonFootprintCalculatorState();

  @override
  List<Object> get props => [];
}

class CarbonFootprintCalculatorInitialState
    extends CarbonFootprintCalculatorState {}

class CarbonFootprintCalculatorLoadingState
    extends CarbonFootprintCalculatorState {}

class CarbonFootprintCalculatorSuccessState
    extends CarbonFootprintCalculatorState {
  const CarbonFootprintCalculatorSuccessState(this.carbonFootprint);

  final CarbonFootprint carbonFootprint;

  @override
  List<Object> get props => [carbonFootprint];
}

class CarbonFootprintCalculatorErrorState
    extends CarbonFootprintCalculatorState {
  const CarbonFootprintCalculatorErrorState(this.errorMessage);

  final String errorMessage;

  @override
  List<Object> get props => [errorMessage];
}
