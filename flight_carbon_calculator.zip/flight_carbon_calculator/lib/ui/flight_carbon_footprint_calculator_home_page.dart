import 'package:flight_carbon_calculator/logic/carbon_footprint_calculator_cubit.dart';
import 'package:flight_carbon_calculator/logic/carbon_footprint_calculator_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:url_launcher/url_launcher.dart';

class FlightCarbonFootprintCalculatorHomePage extends StatefulWidget {
  @override
  _FlightCarbonFootprintCalculatorHomePageState createState() =>
      _FlightCarbonFootprintCalculatorHomePageState();
}

class _FlightCarbonFootprintCalculatorHomePageState
    extends State<FlightCarbonFootprintCalculatorHomePage> {
  final _flightCalculatorCubit = CarbonFootprintCalculatorCubit();

  final _departureTextController = TextEditingController();
  final _arrivalTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.airplanemode_active),
            SizedBox(width: 16),
            Text('Carbon Footprint'),
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
            child: _AirportInputField(
              labelText: 'Departure',
              controller: _departureTextController,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, top: 16),
            child: _AirportInputField(
              labelText: 'Arrival',
              controller: _arrivalTextController,
            ),
          ),
          BlocBuilder<CarbonFootprintCalculatorCubit,
              CarbonFootprintCalculatorState>(
            bloc: _flightCalculatorCubit,
            builder: (builderContext, snapshot) {
              if (snapshot is CarbonFootprintCalculatorLoadingState) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.hourglass_bottom,
                        size: 36,
                      ),
                    ),
                    label: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('Calculating'),
                    ),
                  ),
                );
              } else {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (snapshot is CarbonFootprintCalculatorSuccessState) {
                    showDialog(
                      context: builderContext,
                      builder: (_) {
                        return AlertDialog(
                          scrollable: true,
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Your flight from ${_departureTextController.text} to ${_arrivalTextController.text} caused '
                                '\na total of ${snapshot.carbonFootprint.carbonFootprintValue} meter cubes of carbon dioxide.',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 24),
                              Text(
                                'If you want to compensate this damage, you can check out the links below!',
                                style: TextStyle(
                                  color: Colors.red,
                                ),
                              ),
                              SizedBox(height: 16),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton(
                                    onPressed: () async {
                                      final nytUrl =
                                          'https://www.nytimes.com/guides/year-of-living-better/how-to-reduce-your-carbon-footprint';
                                      if (await canLaunch(nytUrl)) {
                                        await launch(nytUrl);
                                      }
                                    },
                                    child: Text(
                                        'What can I do to make things better?'),
                                  ),
                                  TextButton(
                                    onPressed: () async {
                                      if (await canLaunch(
                                          snapshot.carbonFootprint.url)) {
                                        launch(snapshot.carbonFootprint.url);
                                      }
                                    },
                                    child: Text('See my trip details!'),
                                  ),
                                ],
                              )
                            ],
                          ),
                        );
                      },
                    );
                  } else if (snapshot is CarbonFootprintCalculatorErrorState) {
                    ScaffoldMessenger.of(builderContext).showSnackBar(
                      SnackBar(
                        content: Text(snapshot.errorMessage),
                      ),
                    );
                  }
                });
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: ElevatedButton.icon(
                    onPressed: () {
                      _flightCalculatorCubit
                          .getCarbonPrintInformationForTwoDestinations(
                        departureAirportCode: _departureTextController.text,
                        arrivalAirportCode: _arrivalTextController.text,
                      );
                    },
                    icon: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.calculate,
                        size: 36,
                      ),
                    ),
                    label: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('Calculate'),
                    ),
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _arrivalTextController.dispose();
    _departureTextController.dispose();
    super.dispose();
  }
}

class _AirportInputField extends TextFormField {
  _AirportInputField({
    String labelText,
    TextEditingController controller,
  }) : super(
          controller: controller,
          decoration: InputDecoration(
            labelText: labelText,
            border: OutlineInputBorder(),
          ),
        );
}
